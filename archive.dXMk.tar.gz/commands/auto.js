module.exports = {
    name: "",
    type: "messageCreate",
    code: `
    $if[$checkContains[1114687027573694534;1114686899416748092;1114685878388924537;1114685705818484867;1096184106007674920;$channelID]==false;
    $if[$channelType[$channelID]==GuildPublicThread;
    $if[$getUserVar[userSent;$authorID]==;;
    $if[$getUserVar[threadID;$authorID]==$channelID;
$sendMessage[$channelID;<@860272475626274816> The recruiters have been notified. <@$authorID>, please be patient as they get to your request. In the meantime, make sure you’ve answered all the questions to help them assist you more efficiently.]
    $setUserVar[userSent;;$authorID]
    $setUserVar[threadID;;$authorID]
]]]]
    
    `
}