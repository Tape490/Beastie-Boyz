module.exports = {
    name: "blacklist-update",
    type: "messageCreate",
    
    code: `
$jsonLoad[users;$getGlobalVar[users;[\\]]]
$js[
function parse(d) {
  let [username, ign, league, status\\] = d.split("^");
  return { username, ign, league, status };
}
let text = require("fs").readFileSync("blacklist.txt", "utf8");
let users = ctx.getEnvironmentKey("users");
text.split("|").forEach(d => {
  d = parse(d);
  let i = users.findIndex(x => x.username == d.username);
  if(i > -1) users[i\\] = d; else users.push(d);
});
ctx.setEnvironmentKey("users", users);]
$writeFile[u.json;$env[users]]
$setGlobalVar[users;$env[users]]
    `
}