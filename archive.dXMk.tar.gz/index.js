const { ForgeClient } = require("@tryforge/forgescript")
const { ForgeDB } = require("@tryforge/forge.db")
const { DiscordJS } = require("discord.js")
const { ForgeCanvas } = require("@tryforge/forge.canvas");


// Client initialization
   const client = new ForgeClient({
    "intents": [
        "Guilds",
        "GuildMembers",
        "GuildIntegrations",
        "GuildInvites",
        "GuildPresences",
        "GuildMessages",
        "GuildMessageTyping",
        "DirectMessages",
        "MessageContent",
        "GuildScheduledEvents",
    ],
    "events": [
        "error",
        "messageCreate",
        "guildCreate",
        "guildDelete",
        "interactionCreate",
        "ready",
        "guildMemberAdd",
        "guildMemberUpdate"
    ],
     "prefixes": [
        ".",
    ],
    "extensions": [
        new ForgeCanvas(),
         new ForgeDB()
        ]
}) 
  

client.functions.add({
    name: "chancedKey",
    params: ["keyMap", "chanceMap"],
    code: `
$scope[
$jsonLoad[keys;$env[keyMap]]
$jsonLoad[chances;$env[chanceMap]]

$let[rand;$randomNumber[0;1;true]]
$let[cumulativeProbability;0]

$loop[$arrayLength[keys];
    $let[index;$math[$env[i]-1]]
    $let[cumulativeProbability;$math[$get[cumulativeProbability]+$env[chances;$get[index]]]]
    $if[$get[rand]<=$get[cumulativeProbability];$return[$env[keys;$get[index]]]]
;i]

$return[null]
]
`
});

client.functions.add({
  name: "queryUsers",
  params: ["type", "q"],
  code: `
    $jsonLoad[users;$getGlobalVar[users]]
    $let[i;$arrayFindIndex[users;u;
      $return[$checkCondition[$env[u;$env[type]]==$env[q]]]
    ]]
    $return[$if[$get[i]>-1;$arrayAt[users;$get[i]];]]
  `
});

client.commands.add({
    type: "ready",
    code: `
    $loop[-1;$setStatus[online;Custom;Handling threads.. 👀] $wait[30000] $setStatus[online;Custom;Watching over the Beastie Boyz server! 🔥] $wait[30000]]
    `
})

client.commands.add({
    type: "guildMemberAdd",
    code: `
    $try[
  $log[+ Member joined $username[$authorID]]  
$setUserVar[onboarding;true;$authorID] 

$let[userData;$queryUsers[username;$toLowerCase[$username[$authorID]]]]

$let[displayData;$queryUsers[username;$toLowerCase[$userDisplayName[$authorID]]]]

$sendMessage[1329190162923786403;
$title[New Member Joined!]
$description[<@$authorID> has joined the server!]
$color[FFFFC5]
$addField[**User Info**;
>>> **Username:** $inlineCode[$username[$authorID]]
**ID:** $inlineCode[$authorID]
]
$addField[**Join Info**;
>>> **Total Members:** $inlineCode[$guildMemberCount]
**Boost Level:** $inlineCode[$guildBoostLevel]
]
$footer[Member Join Log;$userAvatar[$botID]]
$thumbnail[$userAvatar[$authorID]]
$timestamp
]

$if[$get[userData]==;

;
  $jsonLoad[info;$get[userData]]
$sendMessage[1329190162923786403;
$title[Blacklisted User Detected!]
$description[A blacklisted user has joined the server.]
$color[#FF0000]
$addField[**User Info**;
>>> **Username:** $inlineCode[$username[$authorID]]
**User ID:** $inlineCode[$authorID]
    ]
    $addField[**Blacklist Details**;
    $codeBlock[$get[userData]]
    ]
    $footer[Blacklist Alert;$userAvatar[$botID]]
    $timestamp
    ]

    $setUserVar[blacklisted;true;$authorID]
    $setUserVar[onboarding;;$authorID]
 
 $let[found;true]
 ]
 
  $if[$get[displayData]==;
  
  ;
  $if[$get[found]==true;
   $jsonLoad[info;$get[displayData]]

    
$sendMessage[1329190162923786403;
$title[Blacklisted User Detected!]
$description[A blacklisted user has joined the server.]
$color[#FF0000]
$addField[**User Info**;
>>> **Username:** $inlineCode[$username[$authorID]]
**User ID:** $inlineCode[$authorID]
    ]
    $addField[**Blacklist Details**;
    $codeBlock[$get[displayData]]
    ]
    $footer[Blacklist Alert;$userAvatar[$botID]]
    $timestamp
    ]

    $setUserVar[blacklisted;true;$authorID]
    $setUserVar[onboarding;;$authorID]
    ]]
    ;
    $log[- Error occured! index.js/guildMemberAdd]
    ]
  `
})

client.commands.add({
    type: "guildMemberUpdate",
    code: `
    $try[
$log[+ Member role update $if[$oldMember[removedRoles]==;null;$oldMember[removedRoles]] -> $oldMember[addedRoles]]
$log[+ Member $username[$authorID], has updated checking now...]  

$if[$getUserVar[blacklisted;$authorID]==true;

$let[sinbinThread;$createThread[1162657775592161351;$username[$authorID];;;]]

$log[Thread created for blacklisted user $username[$authorID] in channel ID: $get[sinbinThread]]

$sendMessage[$get[sinbinThread];
Hi <@$authorID>,
Welcome back to BB! Our system has detected your name in our blacklist. However, one of our admins, Solomon, will get back to you and review your case. If possible, he will waive your ban status to allow you to join one of league. Please give him some time for this process.
]

$sendMessage[$get[sinbinThread];<@740725114785497269>]
$setUserVar[onboarding;;$authorID]
$setUserVar[blacklisted;;$authorID]
$stop
;
$if[$getUserVar[onboarding;$authorID]==true;
$c[roles]
$let[DontKnow;929713821361242204]
$let[Under100;929713672782225418]
$let[101to104;929713965506895942]
$let[105to108;929713998037942333]
$let[109andAbove;929714084411224094]
$let[BBLeagueRole;929714169828237322]
$c[channels]
$let[NoRank;1096184106007674920]
$let[Under100Channel;1096183988248395778]
$let[101to104Channel;1114685705818484867]
$let[105to108Channel;1114685878388924537]
$let[109andAboveChannel;1114686899416748092]
$let[BBLeagueChannel;1114687027573694534]
$if[$checkContains[$memberRoles[$guildID;$authorID;-];1155930395402059826]==true;

$stop
;
$if[$checkContains[$memberRoles[$guildID;$authorID;-];$get[DontKnow]]==true; 
  $let[NoRankThread;$createThread[$get[NoRank];$username[$authorID];;;]]

  $log[Thread created for $username[$authorID] in channel ID: $get[NoRank]]
  $sendMessage[$get[NoRankThread];<@$authorID> Welcome to Beastie Boyz! tada 

Could you please send us the below details:

1.  In-Game Name
2.  Overall of your main team
3. Name of the League (if you have already joined one of our leagues). If not, you will be assigned one. 
4. From where you got the server link. 

Thank you and hope you enjoy your stay here...]
$setUserVar[userSent;false;$authorID]
$setUserVar[threadID;$get[NoRankThread];$authorID]
$setUserVar[roleID;$get[DontKnow];$authorID]
$setUserVar[onboarding;;$authorID]
;
$if[$checkContains[$memberRoles[$guildID;$authorID;-];$get[Under100]]==true; 
  $let[Under100Thread;$createThread[$get[Under100Channel];$username[$authorID];;;]]

  $log[Thread created for $username[$authorID] in channel ID: $get[Under100Channel]]
  $sendMessage[$get[Under100Thread];<@$authorID> Welcome to Beastie Boyz! tada 

Could you please send us the below details:

1.  In-Game Name
2.  Overall of your main team
3. Name of the League (if you have already joined one of our leagues). If not, you will be assigned one. 
4. From where you got the server link. 

Thank you and hope you enjoy your stay here...]
$setUserVar[userSent;false;$authorID]
$setUserVar[threadID;$get[Under100Thread];$authorID]
$setUserVar[roleID;$get[Under100];$authorID]
$setUserVar[onboarding;;$authorID]
;
$if[$checkContains[$memberRoles[$guildID;$authorID;-];$get[101to104]]==true; 
  $let[101to104Thread;$createThread[$get[101to104Channel];$username[$authorID];;;]]

  $log[Thread created for $username[$authorID] in channel ID: $get[101to104Channel]]
  $sendMessage[$get[101to104Thread];<@$authorID> Welcome to Beastie Boyz! tada 

Could you please send us the below details:

1.  In-Game Name
2.  Overall of your main team
3. Name of the League (if you have already joined one of our leagues). If not, you will be assigned one. 
4. From where you got the server link. 

Thank you and hope you enjoy your stay here...]
$setUserVar[userSent;false;$authorID]
$setUserVar[threadID;$get[101to104Thread];$authorID]
$setUserVar[roleID;$get[101to104];$authorID]
$setUserVar[onboarding;;$authorID]
;
$if[$checkContains[$memberRoles[$guildID;$authorID;-];$get[105to108]]==true; 
  $let[105to108Thread;$createThread[$get[105to108Channel];$username[$authorID];;;]]

  $log[Thread created for $username[$authorID] in channel ID: $get[105to108Channel]]
  $sendMessage[$get[105to108Thread];<@$authorID> Welcome to Beastie Boyz! tada 

Could you please send us the below details:

1.  In-Game Name
2.  Overall of your main team
3. Name of the League (if you have already joined one of our leagues). If not, you will be assigned one. 
4. From where you got the server link. 

Thank you and hope you enjoy your stay here...]
$setUserVar[userSent;false;$authorID]
$setUserVar[threadID;$get[105to108Thread];$authorID]
$setUserVar[roleID;$get[105to108];$authorID]
$setUserVar[onboarding;;$authorID]
;
$if[$checkContains[$memberRoles[$guildID;$authorID;-];$get[109andAbove]]==true; 
  $let[109andAboveThread;$createThread[$get[109andAboveChannel];$username[$authorID];;;]]

  $log[Thread created for $username[$authorID] in channel ID: $get[109andAboveThread]]
  $sendMessage[$get[109andAboveThread];<@$authorID> Welcome to Beastie Boyz! tada 

Could you please send us the below details:

1.  In-Game Name
2.  Overall of your main team
3. Name of the League (if you have already joined one of our leagues). If not, you will be assigned one. 
4. From where you got the server link. 

Thank you and hope you enjoy your stay here...]
$setUserVar[userSent;false;$authorID]
$setUserVar[threadID;$get[109andAboveThread];$authorID]
$setUserVar[roleID;$get[109andAbove];$authorID]
$setUserVar[onboarding;;$authorID]
;
$if[$checkContains[$memberRoles[$guildID;$authorID;-];$get[BBLeagueRole]]==true; 
  $let[BBLeagueThread;$createThread[$get[BBLeagueChannel];$username[$authorID];;;]]

  $log[Thread created for $username[$authorID] in channel ID: $get[BBLeagueThread]]
  $sendMessage[$get[BBLeagueChannel];<@$authorID> Welcome to Beastie Boyz! tada 

Could you please send us the below details:

1.  In-Game Name
2.  Overall of your main team
3. Name of the League (if you have already joined one of our leagues). If not, you will be assigned one. 
4. From where you got the server link. 

Thank you and hope you enjoy your stay here...]
$setUserVar[userSent;false;$authorID]
$setUserVar[threadID;$get[BBLeagueThread];$authorID]
$setUserVar[roleID;$get[BBLeagueRole];$authorID]
$setUserVar[onboarding;;$authorID]
]]]]]]]
;
$log[- $username[$authorID] is not a new user]
  ]
]
;$log[- Error occured! index.js/guildMemberUpdate]
]
  `
})

client.commands.load("commands")
client.applicationCommands.load("slashCommands")

const fs = require('fs');
const path = require('path');

// Assuming 'client.functions.add' is already defined and ready to use
// and that it correctly handles the objects being added.

// Directory containing your function modules
const functionsDir = path.join(__dirname, './Custom');

// Read the directory and get an array of filenames
fs.readdirSync(functionsDir).forEach(file => {
  // Ignore non-JavaScript files
  if (!file.endsWith('.js')) return;

  // Full path to the file
  const filePath = path.join(functionsDir, file);

  // Import the function or function object from the file
  const func = require(filePath);

  // Add the imported function to your client
  // This line may need to be adjusted if your function files export differently
  client.functions.add(func);
});

client.login("MTMyNzM0MTI1NzYxMzI1MDYwMQ.GerACf.ObI5TK4IhIpG83gLAQxVGGceZkqFPoGkXr5vsM");