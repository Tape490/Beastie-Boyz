module.exports = {
    data: {
        type: 1,
        name: "role",
        description: "Easily assign roles by choosing a league, which will give the user a role.",
        options: [
            {
                type: 3,
                name: "league",
                description: "Pick a specific league.",
                required: true,
                choices: [
                    { name: "BB Limitless", value: "limitless" },
                    { name: "BB Starbound", value: "starbound" },
                    { name: "BB Destiny", value: "destiny" },
                    { name: "BB Paragon", value: "paragon" },
                    { name: "BB Infantry", value: "infantry" },
                    { name: "BB Fidelity", value: "fidelity" }
                ]
            },
            {
                type: 6,
                name: "user",
                description: "Pick the user you'd like to role.",
                required: true
              },
              {
                type: 3,
                name: "ign",
                description: "Type in the users in-game IGN.",
                required: true
              },
        ]
    },
    code: `
$defer
$onlyIf[$guildID!=;]

$try[
$onlyForRoles[$ephemeral You cannot use this command as you don't have the required permissions;]

$if[$hasRoles[$guildID;$authorID;1155930395402059826]==true;
$ephemeral
Member already has members role. Please ping an admin.
;
$if[$option[league]==fidelity;
$title[**Fidelity Currently Unavailable**]
$description[
> Unfortunately, Fidelity is currently unavailable. As a result, you are unable to assign roles to users at this time.  
Please try again later. We apologize for the inconvenience and appreciate your patience.
]
$color[FFFFC5]
$timestamp
;
$if[$option[league]==limitless;
$title[**Roles Assigned and Nickname Updated**]
$description[
> The member's roles have been successfully assigned, and their nickname has been updated for the league **BB Limitless**.  
They now have access to all designated channels, roles, and features tied to **BB Limitless**.
]
$color[FFFFC5]
$footer[League Update | BB Limitless]
$timestamp
$memberAddRoles[$guildID;$option[user];1155930395402059826;1155938417998299237]
$memberSetNickname[$guildID;$option[user];$option[ign] (BBL)]
;
$if[$option[league]==starbound;
$title[**Roles Assigned and Nickname Updated**]
$description[
> The member's roles have been successfully assigned, and their nickname has been updated for the league **BB Starbound**.  
They now have access to all designated channels, roles, and features tied to **BB Starbound**.
]
$color[FFFFC5]
$footer[League Update | BB Starbound]
$timestamp
$memberAddRoles[$guildID;$option[user];1155930395402059826;1155938542237777960]
$memberSetNickname[$guildID;$option[user];$option[ign] (BBS)]
;
$if[$option[league]==destiny;
$title[**Roles Assigned and Nickname Updated**]
$description[
> The member's roles have been successfully assigned, and their nickname has been updated for the league **BB Destiny**.  
They now have access to all designated channels, roles, and features tied to **BB Destiny**.
]
$color[FFFFC5]
$footer[League Update | BB Destiny]
$timestamp
$memberAddRoles[$guildID;$option[user];1155930395402059826;1155938748043903057]
$memberSetNickname[$guildID;$option[user];$option[ign] (BBD)]
;
$if[$option[league]==paragon;
$title[**Roles Assigned and Nickname Updated**]
$description[
> The member's roles have been successfully assigned, and their nickname has been updated for the league **BB Paragon**.  
They now have access to all designated channels, roles, and features tied to **BB Paragon**.
]
$color[8E44AD]
$footer[League Update | BB Paragon]
$timestamp
$memberAddRoles[$guildID;$option[user];1155930395402059826;1155938950838493234]
$memberSetNickname[$guildID;$option[user];$option[ign] (BBP)]
;
$if[$option[league]==infantry;
$title[**Roles Assigned and Nickname Updated**]
$description[
> The member's roles have been successfully assigned, and their nickname has been updated for the league **BB Infantry**.  
They now have full access to all channels, roles, and features associated with **BB Infantry**.
]
$color[2E86C1]
$footer[League Update | BB Infantry]
$timestamp
$memberAddRoles[$guildID;$option[user];1155930395402059826;1155939066026659971]
$memberSetNickname[$guildID;$option[user];$option[ign] (BBI)]
]]]]]]]
;
An error has occurred while processing this action. Please ping and inform <@1122842723867705356> immediately to address the issue.
$log[- Error has occurred, Error: $env[error]]
;
error
]
 `
}