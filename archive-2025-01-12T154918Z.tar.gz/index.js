const { ForgeClient } = require("@tryforge/forgescript")
const { ForgeDB } = require("@tryforge/forge.db")
const { DiscordJS } = require("discord.js")
const { ForgeCanvas } = require("@tryforge/forge.canvas");


// Client initialization
   const client = new ForgeClient({
    "intents": [
        "Guilds",
        "GuildMembers",
        "GuildIntegrations",
        "GuildInvites",
        "GuildPresences",
        "GuildMessages",
        "GuildMessageTyping",
        "DirectMessages",
        "MessageContent",
        "GuildScheduledEvents",
    ],
    "events": [
        "error",
        "messageCreate",
        "guildCreate",
        "guildDelete",
        "interactionCreate",
        "ready",
        "guildMemberAdd",
        "guildMemberUpdate"
    ],
     "prefixes": [
        ".",
    ],
    "extensions": [
        new ForgeCanvas(),
         new ForgeDB()
        ]
}) 
  

client.functions.add({
    name: "chancedKey",
    params: ["keyMap", "chanceMap"],
    code: `
$scope[
$jsonLoad[keys;$env[keyMap]]
$jsonLoad[chances;$env[chanceMap]]

$let[rand;$randomNumber[0;1;true]]
$let[cumulativeProbability;0]

$loop[$arrayLength[keys];
    $let[index;$math[$env[i]-1]]
    $let[cumulativeProbability;$math[$get[cumulativeProbability]+$env[chances;$get[index]]]]
    $if[$get[rand]<=$get[cumulativeProbability];$return[$env[keys;$get[index]]]]
;i]

$return[null]
]
`
});

client.commands.add({
    type: "guildMemberAdd",
    code: `
    $log[+ Member joined $username[$authorID]]  
   $setUserVar[onboarding;true;$authorID] 

  `
})

client.commands.add({
    type: "guildMemberUpdate",
    code: `
$log[+ Member role update $if[$oldMember[removedRoles]==;null;$oldMember[removedRoles]] -> $oldMember[addedRoles]]
$log[+ Member $username[$authorID], has updated checking now...]  

$if[$getUserVar[onboarding;$authorID]==true;
$c[roles]
$let[DontKnow;1327386760229027891]
$let[Under100;1327386734488584273]
$let[101to104;1327386783612407971]
$let[105to108;1327388659410010204]
$let[109andAbove;1327386806437810186]
$let[BBLeagueRole;1327386831318159440]
$c[channels]
$let[NoRank;1327387093177073736]
$let[Under100Channel;1327387212899156039]
$let[101to104Channel;1327387245199495269]
$let[105to108Channel;1327387278875557888]
$let[109andAboveThread;1327387361738358825]
$let[BBLeagueChannel;1327387419116441651]
$if[$checkContains[$memberRoles[$guildID;$authorID;-];1327432524414320733]==true;

$stop
;
$if[$checkContains[$memberRoles[$guildID;$authorID;-];$get[DontKnow]]==true; 
  $let[NoRankThread;$createThread[$get[NoRank];$username[$authorID];;;]]

  $log[Thread created for $username[$authorID] in channel ID: $get[NoRank]]
  $sendMessage[$get[NoRankThread];<@$authorID> Welcome to Beastie Boyz! tada 

Could you please send us the below details:

1.  In-Game Name
2.  Overall of your main team
3. Name of the League (if you have already joined one of our leagues). If not, you will be assigned one. 
4. From where you got the server link. 

Thank you and hope you enjoy your stay here...]
$setUserVar[userSent;false;$authorID]
$setUserVar[threadID;$get[NoRankThread];$authorID]
$setUserVar[roleID;$get[DontKnow];$authorID]
$setUserVar[onboarding;;$authorID]
;
$if[$checkContains[$memberRoles[$guildID;$authorID;-];$get[Under100]]==true; 
  $let[Under100Thread;$createThread[$get[Under100Channel];$username[$authorID];;;]]

  $log[Thread created for $username[$authorID] in channel ID: $get[Under100Channel]]
  $sendMessage[$get[Under100Thread];<@$authorID> Welcome to Beastie Boyz! tada 

Could you please send us the below details:

1.  In-Game Name
2.  Overall of your main team
3. Name of the League (if you have already joined one of our leagues). If not, you will be assigned one. 
4. From where you got the server link. 

Thank you and hope you enjoy your stay here...]
$setUserVar[userSent;false;$authorID]
$setUserVar[threadID;$get[Under100Thread];$authorID]
$setUserVar[roleID;$get[Under100];$authorID]
$setUserVar[onboarding;;$authorID]
;
$if[$checkContains[$memberRoles[$guildID;$authorID;-];$get[101to104]]==true; 
  $let[101to104Thread;$createThread[$get[101to104Channel];$username[$authorID];;;]]

  $log[Thread created for $username[$authorID] in channel ID: $get[101to104Channel]]
  $sendMessage[$get[101to104Thread];<@$authorID> Welcome to Beastie Boyz! tada 

Could you please send us the below details:

1.  In-Game Name
2.  Overall of your main team
3. Name of the League (if you have already joined one of our leagues). If not, you will be assigned one. 
4. From where you got the server link. 

Thank you and hope you enjoy your stay here...]
$setUserVar[userSent;false;$authorID]
$setUserVar[threadID;$get[101to104Thread];$authorID]
$setUserVar[roleID;$get[101to104];$authorID]
$setUserVar[onboarding;;$authorID]
;
$if[$checkContains[$memberRoles[$guildID;$authorID;-];$get[105to108]]==true; 
  $let[105to108Thread;$createThread[$get[105to108Channel];$username[$authorID];;;]]

  $log[Thread created for $username[$authorID] in channel ID: $get[105to108Channel]]
  $sendMessage[$get[105to108Thread];<@$authorID> Welcome to Beastie Boyz! tada 

Could you please send us the below details:

1.  In-Game Name
2.  Overall of your main team
3. Name of the League (if you have already joined one of our leagues). If not, you will be assigned one. 
4. From where you got the server link. 

Thank you and hope you enjoy your stay here...]
$setUserVar[userSent;false;$authorID]
$setUserVar[threadID;$get[105to108Thread];$authorID]
$setUserVar[roleID;$get[105to108];$authorID]
$setUserVar[onboarding;;$authorID]
;
$if[$checkContains[$memberRoles[$guildID;$authorID;-];$get[109andAbove]]==true; 
  $let[109andAboveThread;$createThread[$get[109andAboveChannel];$username[$authorID];;;]]

  $log[Thread created for $username[$authorID] in channel ID: $get[109andAboveChannel]]
  $sendMessage[$get[109andAboveThread];<@$authorID> Welcome to Beastie Boyz! tada 

Could you please send us the below details:

1.  In-Game Name
2.  Overall of your main team
3. Name of the League (if you have already joined one of our leagues). If not, you will be assigned one. 
4. From where you got the server link. 

Thank you and hope you enjoy your stay here...]
$setUserVar[userSent;false;$authorID]
$setUserVar[threadID;$get[109andAboveChannel];$authorID]
$setUserVar[roleID;$get[109andAbove];$authorID]
$setUserVar[onboarding;;$authorID]
;
$if[$checkContains[$memberRoles[$guildID;$authorID;-];$get[BBLeagueRole]]==true; 
  $let[BBLeagueThread;$createThread[$get[BBLeagueChannel];$username[$authorID];;;]]

  $log[Thread created for $username[$authorID] in channel ID: $get[BBLeagueThread]]
  $sendMessage[$get[BBLeagueChannel];<@$authorID> Welcome to Beastie Boyz! tada 

Could you please send us the below details:

1.  In-Game Name
2.  Overall of your main team
3. Name of the League (if you have already joined one of our leagues). If not, you will be assigned one. 
4. From where you got the server link. 

Thank you and hope you enjoy your stay here...]
$setUserVar[userSent;false;$authorID]
$setUserVar[threadID;$get[BBLeagueThread];$authorID]
$setUserVar[roleID;$get[BBLeagueRole];$authorID]
$setUserVar[onboarding;;$authorID]
]]]]]]]
;
$log[- $username[$authorID] is not a new user]
]
  `
})



client.commands.load("commands")
client.applicationCommands.load("slashCommands")

const fs = require('fs');
const path = require('path');

// Assuming 'client.functions.add' is already defined and ready to use
// and that it correctly handles the objects being added.

// Directory containing your function modules
const functionsDir = path.join(__dirname, './Custom');

// Read the directory and get an array of filenames
fs.readdirSync(functionsDir).forEach(file => {
  // Ignore non-JavaScript files
  if (!file.endsWith('.js')) return;

  // Full path to the file
  const filePath = path.join(functionsDir, file);

  // Import the function or function object from the file
  const func = require(filePath);

  // Add the imported function to your client
  // This line may need to be adjusted if your function files export differently
  client.functions.add(func);
});

client.login("MTMyNzM0MTI1NzYxMzI1MDYwMQ.GerACf.ObI5TK4IhIpG83gLAQxVGGceZkqFPoGkXr5vsM");