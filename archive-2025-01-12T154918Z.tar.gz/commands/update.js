module.exports = {
    name: "up",
    type: "messageCreate",
    code: `
    
$if[$checkContains[$authorID;$botOwnerID;1122842723867705356]==true;
    $updateCommands
    $updateApplicationCommands 
$function[$addMessageReactions[$channelID;$messageID;👍]]]
    
    `
}