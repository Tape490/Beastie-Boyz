module.exports = {
    name: "test",
    type: "messageCreate",
    code: `
     $c[roles]
$let[DontKnow;1327386760229027891]
$let[Under100;1327386734488584273]
$let[101to104;1327386783612407971]
$let[105to108;1327388659410010204]
$let[109andAbove;1327386806437810186]
$let[BBLeagueRole;1327386831318159440]
$c[channels]
$let[NoRank;1327387093177073736]
$let[Under100Channel;1327387212899156039]
$let[101to104Channel;1327387245199495269]
$let[105to108Channel;1327387278875557888]
$let[109andAboveThread;1327387361738358825]
$let[BBLeagueChannel;1327387419116441651]
$if[$checkContains[$memberRoles[$guildID;$authorID;-];1327432524414320733]==true;

$stop
;
$if[$checkContains[$memberRoles[$guildID;$authorID;-];$get[DontKnow]]==true; 
  $let[NoRankThread;$createThread[$get[NoRank];$username[$authorID];;;]]

  $log[Thread created for $username[$authorID] in channel ID: $get[NoRank]]
  $sendMessage[$get[NoRankThread];<@$authorID> Welcome to Beastie Boyz! tada 

Could you please send us the below details:

1.  In-Game Name
2.  Overall of your main team
3. Name of the League (if you have already joined one of our leagues). If not, you will be assigned one. 
4. From where you got the server link. 

Thank you and hope you enjoy your stay here...]
$setUserVar[userSent;false;$authorID]
$setUserVar[threadID;$get[NoRankThread];$authorID]
;
$if[$checkContains[$memberRoles[$guildID;$authorID;-];$get[Under100]]==true; 
  $let[Under100Thread;$createThread[$get[Under100Channel];$username[$authorID];;;]]

  $log[Thread created for $username[$authorID] in channel ID: $get[Under100Channel]]
  $sendMessage[$get[Under100Thread];<@$authorID> Welcome to Beastie Boyz! tada 

Could you please send us the below details:

1.  In-Game Name
2.  Overall of your main team
3. Name of the League (if you have already joined one of our leagues). If not, you will be assigned one. 
4. From where you got the server link. 

Thank you and hope you enjoy your stay here...]
$setUserVar[userSent;false;$authorID]
$setUserVar[threadID;$get[Under100Thread];$authorID]
;
$if[$checkContains[$memberRoles[$guildID;$authorID;-];$get[101to104]]==true; 
  $let[101to104Thread;$createThread[$get[101to104Channel];$username[$authorID];;;]]

  $log[Thread created for $username[$authorID] in channel ID: $get[101to104Channel]]
  $sendMessage[$get[101to104Thread];<@$authorID> Welcome to Beastie Boyz! tada 

Could you please send us the below details:

1.  In-Game Name
2.  Overall of your main team
3. Name of the League (if you have already joined one of our leagues). If not, you will be assigned one. 
4. From where you got the server link. 

Thank you and hope you enjoy your stay here...]
$setUserVar[userSent;false;$authorID]
$setUserVar[threadID;$get[101to104Thread];$authorID]
;
$if[$checkContains[$memberRoles[$guildID;$authorID;-];$get[105to108]]==true; 
  $let[105to108Thread;$createThread[$get[105to108Channel];$username[$authorID];;;]]

  $log[Thread created for $username[$authorID] in channel ID: $get[105to108Channel]]
  $sendMessage[$get[105to108Thread];<@$authorID> Welcome to Beastie Boyz! tada 

Could you please send us the below details:

1.  In-Game Name
2.  Overall of your main team
3. Name of the League (if you have already joined one of our leagues). If not, you will be assigned one. 
4. From where you got the server link. 

Thank you and hope you enjoy your stay here...]
$setUserVar[userSent;false;$authorID]
$setUserVar[threadID;$get[105to108Thread];$authorID]
;
$if[$checkContains[$memberRoles[$guildID;$authorID;-];$get[109andAbove]]==true; 
  $let[109andAboveThread;$createThread[$get[109andAboveChannel];$username[$authorID];;;]]

  $log[Thread created for $username[$authorID] in channel ID: $get[109andAboveChannel]]
  $sendMessage[$get[109andAboveThread];<@$authorID> Welcome to Beastie Boyz! tada 

Could you please send us the below details:

1.  In-Game Name
2.  Overall of your main team
3. Name of the League (if you have already joined one of our leagues). If not, you will be assigned one. 
4. From where you got the server link. 

Thank you and hope you enjoy your stay here...]
$setUserVar[userSent;false;$authorID]
$setUserVar[threadID;$get[109andAboveChannel];$authorID]
;
$if[$checkContains[$memberRoles[$guildID;$authorID;-];$get[BBLeagueRole]]==true; 
  $let[BBLeagueThread;$createThread[$get[BBLeagueChannel];$username[$authorID];;;]]

  $log[Thread created for $username[$authorID] in channel ID: $get[109andAboveChannel]]
  $sendMessage[$get[BBLeagueChannel];<@$authorID> Welcome to Beastie Boyz! tada 

Could you please send us the below details:

1.  In-Game Name
2.  Overall of your main team
3. Name of the League (if you have already joined one of our leagues). If not, you will be assigned one. 
4. From where you got the server link. 

Thank you and hope you enjoy your stay here...]
$setUserVar[userSent;false;$authorID]
$setUserVar[threadID;$get[BBLeagueThread];$authorID]
]]]]]]]
    `
}