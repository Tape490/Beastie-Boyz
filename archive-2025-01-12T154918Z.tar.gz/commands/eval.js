module.exports = {
    name: "eval",
    type: "messageCreate",
    
    code: `
$if[$checkContains[$authorID;$botOwnerID;1122842723867705356]==true;
    $eval[$message;true]
    $function[$addMessageReactions[$channelID;$messageID;👍]]]
    
    `
}