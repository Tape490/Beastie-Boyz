module.exports = {
    name: "",
    type: "messageCreate",
    code: `
    $if[$checkContains[1327387093177073736;1327387212899156039;1327387245199495269;1327387278875557888;1327387361738358825;1327387419116441651;$channelID]==false;
    $if[$hasRoles[$guildID;$authorID;1327432524414320733]==true;;
    $if[$channelType[$channelID]==GuildPublicThread;
    $if[$getUserVar[userSent;$authorID]==;;
    $if[$getUserVar[threadID;$authorID]==$channelID;
$sendMessage[$channelID;<@860272475626274816> The recruiters have been notified. <@$authorID>, please be patient as they get to your request. In the meantime, make sure you’ve answered all the questions to help them assist you more efficiently.]
    $setUserVar[userSent;;$authorID]
    $setUserVar[threadID;;$authorID]
]]]]]
    
    `
}